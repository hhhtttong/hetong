# Air-Universe-install

快速使用
```shell
bash <(curl -Ls https://raw.githubusercontent.com/crossfw/Air-Universe-install/master/AirU.sh)
```


